from django.shortcuts import render
from django.http import HttpResponse
from new_app.models import Topic, Webpage, AccessRecord


# Create your views here.
def index(request):
  Webpage_list = AccessRecord.objects.order_by('date')
  date_context = {"access_records": Webpage_list }
  return render(request, 'new_app/index.html', context = date_context)