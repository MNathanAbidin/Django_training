from django import forms
from subscribe_app.models import Customer


class NewSubscriberForm(forms.ModelForm):
  class Meta:
    model = Customer
    fields = ['first_name', 'last_name', 'email']