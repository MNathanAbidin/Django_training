from django.shortcuts import render
from subscribe_app.models import Customer
from subscribe_app.forms import NewSubscriberForm

# Create your views here.
def index(request):
  customers = Customer.objects.all()
  return render(request, 'subscribe_app/index.html', {'customers': customers})

def customers(request):
  customer_list = Customer.objects.order_by('first_name')
  customer_dict = {'customers': customer_list}
  return render(request, 'subscribe_app/customers.html', context=customer_dict)

def subscribe(request):
  form = NewSubscriberForm()
  if request.method == 'POST':
    form = NewSubscriberForm(request.POST)
    if form.is_valid():
      form.save(commit=True)
      return customers(request)
    else:
      print("ERROR FORM INVALID")
      
  return render(request, 'subscribe_app/subscribe.html', {'form': form})